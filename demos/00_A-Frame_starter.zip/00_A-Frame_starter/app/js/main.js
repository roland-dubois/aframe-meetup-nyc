AFRAME.registerComponent('custom-component', {
  init: function () {
    var targetEl = this.el;    
  }
});
